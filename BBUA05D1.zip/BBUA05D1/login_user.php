<?php
include('functions.php');
$result = array("success" => 0, "error" => 0);

if (isset($_POST['UserNameLogin']) && isset($_POST['PasswordLogin'])) {
    $username = $_POST['UserNameLogin'];
    $password = md5($_POST['PasswordLogin']); 

    $func = new functions();
    $login = $func->login_user('user', $username, $password);

    if ($login != false) {
        $result["success"] = 1;
        $result["msg_success"] = "Successfully logged in";
        print json_encode($result);

    } else {
        $result["error"] = 2;
        $result["msg_error"] = "Invalid credentials";
        print json_encode($result);

    }
} else {
    $result["error"] = 1;
    $result["msg_error"] = "Access denied";
    print json_encode($result);
}
?>
