<?php
include('functions.php');
$result = array("success" => 0, "error" => 0);

if (isset($_POST['CategoryName']) && isset($_POST['Description'])) {
    $name = $_POST['CategoryName'];
    $description = $_POST['Description'];
     // Removed unnecessary md5() function

    $fields = array("CategoryName", "Description" );
    $values = array($name, $description);

    $func = new functions();
    $insert = $func->insert_data('category', $fields, $values);

    if ($insert == true) {
        $result["success"] = 1;
        $result["msg_success"] = "Successfully Created Category";
        echo json_encode($result); // Corrected function name

    } else {
        $result["error"] = 2;
        $result["msg_error"] = "Failed to Create Category";
        echo json_encode($result); // Corrected function name

    }
} else {
    $result["error"] = 1;
    $result["msg_error"] = "Access denied";
    echo json_encode($result); // Corrected function name
}
?>
