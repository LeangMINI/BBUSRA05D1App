<?php
    define("DB_HOST","Localhost");
    define("DB_USER","root");
    define("DB_PWD","");
    define("DB_NAME","a05d1");
?>